from atk import Atk
from efeito import Efeito
from slayer import Slayer
from oni import Oni
from personagens import PERSONAGENS  # opcional, se quiser listar

import time  # só pra dar ritmo nos prints (mais imersão)

def listar_personagens(personagens: dict):
    print("\n" + "=" * 40)
    print("🌸  LISTA DE PERSONAGENS DISPONÍVEIS  🌸")
    print("=" * 40)

    for num, p in personagens.items():
        print(f"\n[{num}] 🧍 {p['nome'].upper()} ({p['tipo']})")
        print("-" * 40)
        print(f"  🧠 Idade: {p.get('idade', '??')} anos")
        print(f"  ❤️ Vida: {p.get('vida', '??')}")
        print(f"  💨 Esquiva: {p.get('esquiva', 0) * 100:.0f}%")
        print(f"  🌬️ Respiração: {p.get('tipo_resp', 'Nenhuma')}")
        print(f"  ⚔️ Ataque Base: {p['atk'].dano if 'atk' in p else 'N/A'}")
        print(f"  ☠️ Efeito: {p['atk'].efeito.tipo if 'atk' in p else 'N/A'}")
        print("-" * 40)
    print()

def main():
    print("=== SELEÇÃO DE PERSONAGEM ===")

    # Jogador 1 escolhe
    print("\n👤 Jogador 1, escolha seu personagem:")
    listar_personagens(PERSONAGENS)
    escolha_p1 = int(input("Digite o número do personagem: "))
    personagem_p1 = PERSONAGENS[escolha_p1]

    # Criar p1 dinamicamente
    if personagem_p1["tipo"] == "Slayer":
        p1 = Slayer(
            personagem_p1["nome"],
            personagem_p1["idade"],
            personagem_p1["vida"],
            personagem_p1["esquiva"],
            personagem_p1["tipo_resp"],
            personagem_p1["hashira"],
            personagem_p1["atk"]
        )
    elif personagem_p1["tipo"] == "Oni":
        p1 = Oni(
            personagem_p1["nome"],
            personagem_p1["idade"],
            personagem_p1["vida"],
            personagem_p1["esquiva"],
            personagem_p1["tipo_resp"],
            personagem_p1["regen"],  # <- usa o valor definido no dicionário
            personagem_p1["atk"]
        )

    print(f"\n✅ {p1.nome} escolhido(a)!\n")

    # Jogador 2 escolhe
    print("\n👤 Jogador 2, escolha seu personagem:")
    listar_personagens(PERSONAGENS)
    while True:
        escolha_p2 = int(input("Digite o número do personagem: "))
        if escolha_p2 == escolha_p1:
            print("❌ Esse personagem já foi escolhido! Escolha outro.")
        else:
            break

    personagem_p2 = PERSONAGENS[escolha_p2]

    if personagem_p2["tipo"] == "Slayer":
        p2 = Slayer(
            personagem_p2["nome"],
            personagem_p2["idade"],
            personagem_p2["vida"],
            personagem_p2["esquiva"],
            personagem_p2["tipo_resp"],
            personagem_p2["hashira"],
            personagem_p2["atk"]
        )
    elif personagem_p2["tipo"] == "Oni":
        p2 = Oni(
            personagem_p2["nome"],
            personagem_p2["idade"],
            personagem_p2["vida"],
            personagem_p2["esquiva"],
            personagem_p2["tipo_resp"],
            personagem_p2["regen"],  # <- usa o valor definido no dicionário
            personagem_p2["atk"]
        )

    print(f"\n✅ {p2.nome} escolhido(a)!\n")

    # -------------------------
    # 🎯 COMEÇA A BATALHA
    # -------------------------
    print("\n⚔️  COMEÇA A BATALHA! ⚔️\n")
    time.sleep(1)

    exit_game = False
    turno = 1

    while p1.vida > 0 and p2.vida > 0 and not exit_game:
        print(f"\n========== 🌀 TURNO {turno} 🌀 ==========")

        # -------------------------------
        # TURNO P1
        # -------------------------------
        print(f"\n🎴 {p1.nome}, é sua vez!")
        p1.lista_acoes()
        acao = input("Escolha uma ação (1 = atacar, 2 = esquivar, exit = sair): ")

        if acao.lower() == "exit":
            exit_game = True
            break

        elif acao == "1":  # atacar
            if p2.conseguiu_esquivar == 0:
                if p1.atk.efeito.dano_poison != 0:
                    p2.envenenado += p1.atk.efeito.dano_poison
                dano_total = p1.atk.dano + p2.envenenado
                p2.vida -= dano_total
                p2.ajustar_vida()
                print(f"💥 {p1.nome} atacou {p2.nome}! Dano total: {dano_total}")
                p1.mostrar_vida()
                p2.mostrar_vida()
            else:
                print(f"😎 {p2.nome} esquivou do ataque!")
                p2.conseguiu_esquivar = 0  # resetar
        elif acao == "2":
            p1.esquivar()

        time.sleep(1)

        # Verifica se p2 morreu
        if p2.vida <= 0:
            print(f"\n💀 {p2.nome} foi derrotado(a)! {p1.nome} venceu!")
            break

        if isinstance(p1, Oni):
            p1.vida += p1.regen
            p1.ajustar_vida()  # <-- evitar ultrapassar vida_max
            print(f"🩸 {p1.nome} regenerou {p1.regen} de vida (total {p1.vida}/{p1.vida_max})")

        # -------------------------------
        # TURNO P2
        # -------------------------------
        print(f"\n🔥 {p2.nome}, é sua vez!")
        p2.lista_acoes()
        acao = input("Escolha uma ação (1 = atacar, 2 = esquivar, exit = sair): ")

        if acao.lower() == "exit":
            exit_game = True
            break


        if acao == "1":  # atacar
            if p1.conseguiu_esquivar == 0:
                if p2.atk.efeito.dano_poison != 0:
                    p1.envenenado += p2.atk.efeito.dano_poison
                dano_total = p2.atk.dano + p1.envenenado
                p1.vida -= dano_total
                print(f"💥 {p2.nome} atacou {p1.nome}! Dano total: {dano_total}")
            else:
                print(f"😏 {p1.nome} desviou com estilo!")
                p1.conseguiu_esquivar = 0
        elif acao == "2":
            p2.esquivar()

        # Verifica se p1 morreu
        if p1.vida <= 0:
            print(f"\n💀 {p1.nome} foi derrotado! {p2.nome} venceu!")
            break

        if isinstance(p2, Oni):
            p2.vida += p2.regen
            p2.ajustar_vida()  # <-- evitar ultrapassar vida_max
            print(f"🩸 {p2.nome} regenerou {p2.regen} de vida (total {p2.vida}/{p2.vida_max})")
            p2.mostrar_vida()

        turno += 1
        time.sleep(1)

    print("\n🏁 Fim da batalha!")


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/


#problema: o veneno está apenas se somando ao dano, não fazendo grande diferença a não ser por causar um ataque de dano maior - PENSAR EM COMO VENENO FUNCIONARÁ